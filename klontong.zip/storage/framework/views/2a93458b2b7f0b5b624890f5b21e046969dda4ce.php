<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="card card-default">
                    <div class="card-header card-header-border-bottom">
                        Edit Bank Toko <?php echo e($store->name); ?>

                    </div>
                    <div class="card-body">
                        <?php echo $__env->make('admin.partials.flash', ['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <form action="<?php echo e(route('store_banks.update', $store_bank->id)); ?>" method="POST">
                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="bank_name">Nama Bank</label>
                                <input type="text" class="form-control" id="bank_name"
                                        value="<?php echo e(old('bank_name') ? old('bank_name') : $store_bank->bank_name); ?>"
                                        name="bank_name" placeholder="Masukkan Nama Bank">
                                <span class="mt-2 d-block">* Harus Unik.</span>
                            </div>
                            <div class="form-group">
                                <label for="nomor_rekening">Nomor Rekening</label>
                                <input type="text" class="form-control" id="nomor_rekening"
                                        value="<?php echo e(old('nomor_rekening') ? old('nomor_rekening') : $store_bank->nomor_rekening); ?>"
                                        name="nomor_rekening" placeholder="Masukkan Nomor Rekening">
                                <span class="mt-2 d-block">* Harus Unik.</span>
                            </div>
                            <div class="form-group">
                                <label for="bank_name">Atas Nama</label>
                                <input type="text" class="form-control" id="atas_nama"
                                        value="<?php echo e(old('atas_nama') ? old('atas_nama') : $store_bank->atas_nama); ?>"
                                        name="atas_nama" placeholder="Masukkan Atas Nama">
                                <span class="mt-2 d-block">* Harus Unik.</span>
                            </div>
                            <div class="form-footer pt-2 border-top">
                                <button type="submit" class="btn btn-primary btn-default">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wiku\PROJEK\2 anggara\new klontong\klontong\resources\views/admin/store_banks/edit.blade.php ENDPATH**/ ?>