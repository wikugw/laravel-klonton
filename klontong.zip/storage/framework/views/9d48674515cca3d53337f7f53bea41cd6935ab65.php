<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-7 heading-section ftco-animate fadeInUp ftco-animated" align="center">
                <h2 class="mb-4">Transaksi Berhasil</h2>
                <img src="<?php echo e(url('storage/success-buy.png')); ?>" width="50%"/>
                <p class="pt-5">Anda dapat melihat data transaksi pada tab
                    <a href="<?php echo e(route('home.transactions')); ?>">transaksi</a> atau kembali pada halaman
                    <a href="<?php echo e(route('home')); ?>">utama</a>
                </p>
              </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wiku\PROJEK\2 anggara\new klontong\klontong\resources\views/user/success.blade.php ENDPATH**/ ?>