<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="row">
            <div class="col-lg-12">
                <div class="card card-default">
                    <div class="card-header card-header-border-bottom">
                        Edit Produk <?php echo e($product->name); ?>

                    </div>
                    <div class="card-body">
                        <?php echo $__env->make('admin.partials.flash', ['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <form action="<?php echo e(route('products.update', $product->id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="name">Nama Produk</label>
                                        <input  type="text" class="form-control" id="name" name="name"
                                                value="<?php echo e(old('name') ? old('name') : $product->name); ?>"
                                                placeholder="Masukkan nama produk anda">
                                        <span class="mt-2 d-block">* Wajib diisi.</span>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="category_id">Kategori</label>
                                        <select name="category_id" class="form-control">
                                                <option value="<?php echo e($product->category_id); ?>"><?php echo e($product->category->name); ?></option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="weight">Berat Produk (dalam gram)</label>
                                        <input  type="number" class="form-control" id="weight" name="weight"
                                                value="<?php echo e(old('weight') ? old('weight') : $product->weight); ?>"
                                                placeholder="Masukkan berat produk anda contoh 1000">
                                        <span class="mt-2 d-block">* Wajib diisi.</span>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="price">Harga Produk</label>
                                        <input  type="number" class="form-control" id="price" name="price"
                                                value="<?php echo e(old('price') ? old('price') : $product->price); ?>"
                                                placeholder="Masukkan harga produk anda contoh 15000">
                                        <span class="mt-2 d-block">* Wajib diisi.</span>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    
                                    <div class="form-group">
                                        <label for="deskripsi">Deskripsi Produk</label>
                                        <textarea class="form-control" id="deskripsi" name="description" rows="7"><?php echo e(old('description') ? old('description') : $product->description); ?></textarea>
                                        <span class="mt-2 d-block">* Wajib diisi.</span>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="is_available">Tersedia</label>
                                        <select name="is_available" class="form-control">
                                            <?php if($product->is_available == '0'): ?>
                                            <option value="<?php echo e($product->is_available); ?>">Tidak</option>
                                            <?php else: ?>
                                            <option value="<?php echo e($product->is_available); ?>">Tersedia</option>
                                            <?php endif; ?>
                                            <option value="0">Tidak</option>
                                            <option value="1">Tersedia</option>
                                        </select>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="image">Gambar</label>
                                        <input type="file" class="form-control-file" name="image" id="image">
                                    </div>
                                </div>
                            </div>
                            <div class="form-footer pt-2 border-top">
                                <button type="submit" class="btn btn-primary btn-default">Save</button>
                                <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary btn-default">Back</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wiku\PROJEK\2 anggara\new klontong\klontong\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>