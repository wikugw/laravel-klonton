<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="row">
            <div class="col-lg-12">
                <div class="card card-default">
                    <div class="card-header card-header-border-bottom">
                        <h2>Produk</h2>
                    </div>

                    
                    <?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <div class="card-body">
                        <table id="basic-data-table" class="table nowrap" style="width:100%">
                            <thead>
                              <tr>
                              <th>#</th>
                              <th>Nama</th>
                              <th>Email</th>
                              <th>No. HP</th>
                              <th>Role</th>
                              <th>Toko</th>
                              <th>Action</th>
                             </tr>
                            </thead>

                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($user->id); ?></td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->phone_number); ?></td>
                                        <td>
                                            <?php if($user->role_id == '1'): ?>
                                                <span class="badge badge-primary">Admin</span>
                                            <?php else: ?>
                                                <span class="badge badge-success">User</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($user->store_id == ''): ?>
                                                -
                                            <?php else: ?>
                                            <?php echo e($user->store['name']); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a  href="<?php echo e(route('users.show', $user->id)); ?>" class="btn btn-sm btn-info"><span class="mdi mdi-eye"></span></a>
                                            <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="post" class="d-inline">
                                                <?php echo method_field('delete'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button class="btn btn-sm btn-danger"
                                                        onclick="return confirm('Yakin ingin menghapus user?');"
                                                >
                                                    <span class="mdi mdi-delete"></span>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <td class="text-center" colspan="7"> User tidak ditemukan </td>
                                <?php endif; ?>
                            </tbody>
                           </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wiku\PROJEK\2 anggara\new klontong\klontong\resources\views/admin/users/index.blade.php ENDPATH**/ ?>