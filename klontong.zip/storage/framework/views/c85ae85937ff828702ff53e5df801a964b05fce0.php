<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-6 mb-5 ftco-animate fadeInUp ftco-animated">
            <a href="<?php echo e(url($store->profile)); ?>" class="image-popup"><img src="<?php echo e(route('gambar', ['path' => $store->profile])); ?>" class="img-fluid"
                    alt="Colorlib Template"></a>
        </div>
        <div class="col-lg-6 product-details pl-md-5 ftco-animate fadeInUp ftco-animated">
            <h3><?php echo e($store->name); ?></h3>
            <div class="rating d-flex">
                <p class="text-left mr-4">
                    <a href="#" class="mr-2" style="color: #000;"><?php echo e($products->count()); ?> <span style="color: #bbb;">Produk</span></a>
                </p>
                <p class="text-left">
                    <a href="#" class="mr-2" style="color: #000;"><?php echo e($transactions->count()); ?> <span style="color: #bbb;">Transaksi</span></a>
                </p>
            </div>
            <h5>Deskripsi</h5>
            <p><?php echo e($store->description); ?></p>
            <h5>Alamat</h5>
            <p>
                <?php echo e($address->adrress); ?> <br>
                <?php echo e($address->city->city_name); ?> <br>
                <?php echo e($address->province->province); ?> <br>
                Kode pos :  <?php echo e($address->postal_code); ?> <br>
                No. HP :  <?php echo e($address->phone); ?> (<?php echo e($store->user->name); ?>) <br>
            </p>
            <a href="https://api.whatsapp.com/send?phone=<?php echo e($address->phone); ?>&text=Saya%20ingin%20menanyakan%20salah%20satu%20produk%20yang%20anda%20jual&source=&data=&app_absent=" style="color: green" target="_blank" ><ion-icon size="large" name="logo-whatsapp"></ion-icon></a>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-12 col-lg-12 order-md-last">
            <h3 class="py-3">Produk yang tersedia</h3>
            <div class="row">
                
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-sm-6 col-md-6 col-lg-3 ftco-animate">
                    <div class="product">
                        <a href="#" class="img-prod"><img class="img-fluid" src="<?php echo e(route('gambar', ['path' => $product->image])); ?>" alt="Colorlib Template" style="height: 300px; object-fit: contain" width="100%">
                            <div class="overlay"></div>
                        </a>
                        <div class="text py-3 px-3">
                            <h3><a href="#"><?php echo e($product->name); ?></a></h3>
                            <div class="d-flex">
                                <div class="pricing">
                                    <p class="price"><span>Rp. <?php echo e($product->price); ?></span></p>
                                </div>
                            </div>
                            <p class="bottom-area d-flex px-3">
                                <a href="<?php echo e(route('carts.add', $product->id)); ?>" class="add-to-cart text-center py-2 mr-1"><span>Add to cart <i class="ion-ios-add ml-1"></i></span></a>
                                <a href="<?php echo e(route('home.product', $product->id)); ?>" class="buy-now text-center py-2">Detail<span><i class="ion-ios-eye ml-1"></i></span></a>
                            </p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="container">
                    <div class="row justify-content-center mt-5 mb-3 pb-3">
              <div class="col-md-12 heading-section text-center ftco-animate fadeInUp ftco-animated">
                <h4 class="mb-4">Produk tidak ditemukan :(</h4>
              </div>
            </div>
            </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wiku\PROJEK\2 anggara\new klontong\klontong\resources\views/user/store.blade.php ENDPATH**/ ?>