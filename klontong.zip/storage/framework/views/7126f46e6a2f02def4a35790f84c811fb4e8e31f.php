<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12 ftco-animate">
            <div class="cart-list">
                <table class="table">
                    <thead class="thead-primary">
                        <tr class="text-center">
                            <th>&nbsp;</th>
                            <th>&nbsp;</th>
                            <th>Product</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Total</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $cart_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="text-center">
                            <td class="product-remove">
                                <form action="<?php echo e(route('carts.destroy', $cart_detail->id)); ?>" method="post"
                                    class="d-inline">
                                    <?php echo method_field('delete'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-sm btn-primary">
                                        <span class="ion-ios-close">
                                    </button>
                                </form>
                            </td>

                            <td class="image-prod">
                                <img class="img-fluid" src="<?php echo e(route('gambar', ['path' => $cart_detail->product->image])); ?>"
                                    alt="Colorlib Template" style=" object-fit: contain" width="100px">
                            </td>

                            <td class="product-name">
                                <h3><?php echo e($cart_detail->product->name); ?></h3>
                            </td>

                            <td class="price">Rp. <?php echo e($cart_detail->product->price); ?> </td>

                            <td class="quantity">
                                <div class="input-group mb-3">
                                    <input type="text" name="quantity" class="quantity form-control input-number"
                                        readonly value=<?php echo e($cart_detail->quantity); ?> min="1" max="100">
                                </div>
                            </td>

                            <td class="total">Rp. <?php echo e($cart_detail->total_price()); ?></td>

                            <td>
                                <div class="row pl-1">
                                    <?php if($cart_detail->quantity > 1): ?>
                                    <a href="<?php echo e(route('carts.decrement_quantity', $cart_detail->id)); ?>"
                                        class="btn btn-sm btn-secondary"><span class="ion-ios-remove"></a>
                                    <?php endif; ?>
                                    <a href="<?php echo e(route('carts.show', $cart_detail->id)); ?>"
                                        class="btn btn-sm btn-primary mx-1">Checkout</a>
                                    <a href="<?php echo e(route('carts.increment_quantity', $cart_detail->id)); ?>"
                                        class="btn btn-sm btn-info"><span class="ion-ios-add"></a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <td class="text-center" colspan="8">Belum ada barang pada keranjang</td>
                        <?php endif; ?>
                        <!-- END TR-->

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wiku\PROJEK\2 anggara\new klontong\klontong\resources\views/user/cart.blade.php ENDPATH**/ ?>