<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="row">
            <div class="col-lg-12">
                <div class="card card-default">
                    <div class="card-header card-header-border-bottom">
                        Buat Toko
                    </div>
                    <div class="card-body">
                        <?php echo $__env->make('admin.partials.flash', ['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <form action="<?php echo e(route('stores.update', $store->id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="name">Nama Toko</label>
                                        <input  type="text" class="form-control" id="name" name="name"
                                                value="<?php echo e(old('name') ? old('name') : $store->name); ?>"
                                                placeholder="Masukkan nama toko anda">
                                        <span class="mt-2 d-block">* Wajib diisi.</span>
                                    </div>
                                    <div class="form-group">
                                        <label for="profil">Profil Toko</label>
                                        <input type="file" class="form-control-file" name="profile_toko" id="profil">
                                        <span class="mt-2 d-block">* Dapat dikosongi.</span>
                                    </div>
                                    <div class="form-group">
                                        <label for="foto_ktp">Foto KTP</label>
                                        <input type="file" class="form-control-file" name="foto_ktp" id="foto_ktp">
                                        <span class="mt-2 d-block">* Dapat dikosongi.</span>
                                    </div>
                                    <div class="form-group">
                                        <label for="deskripsi">Deskripsi Toko</label>
                                        <textarea class="form-control" id="deskripsi" name="description" rows="10"><?php echo e(old('description') ? old('description') : $store->description); ?></textarea>
                                        <span class="mt-2 d-block">* Wajib diisi.</span>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    
                                    <div class="form-group">
                                        <label for="adress">Alamat Toko</label>
                                        <textarea class="form-control" id="adress" name="adrress" rows="5"><?php echo e(old('name') ? old('name') : $address->adrress); ?></textarea>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="postal_code">Kode Pos</label>
                                        <input  type="number" class="form-control" id="postal_code"
                                                value="<?php echo e(old('postal_code') ? old('postal_code') : $address->postal_code); ?>"
                                                name="postal_code" placeholder="Masukkan Kode Pos">
                                        <span class="mt-2 d-block">* Wajib diisi.</span>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="province_id">Provinsi</label>
                                        <select name="province_id" class="form-control">
                                            <option value="<?php echo e($address->province_id); ?>"><?php echo e($address->province->province); ?></option>
                                            <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($province->id); ?>"><?php echo e($province->province); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="city_id">Kota</label>
                                        <select name="city_id" class="form-control">
                                            <option value="<?php echo e($address->city_id); ?>"><?php echo e($address->city->city_name); ?></option>
                                            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($city->id); ?>"><?php echo e($city->city_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="phone">Nomor Telepon</label>
                                        <small>Rubah angka '0' dengan kode telepon, '62' untuk Indonesia</small>
                                        <input type="number" class="form-control" id="phone" name="phone"
                                        value="<?php echo e(old('phone') ? old('phone') : $address->phone); ?>"
                                        placeholder="contoh 6282142708802">
                                        <span class="mt-2 d-block">* Wajib diisi.</span>
                                    </div>
                                </div>
                            </div>
                            <div class="form-footer pt-2 border-top">
                                <button type="submit" class="btn btn-primary btn-default">Save</button>
                                <a href="<?php echo e(URL::previous()); ?>" class="btn btn-secondary btn-default">Back</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wiku\PROJEK\2 anggara\new klontong\klontong\resources\views/admin/stores/edit.blade.php ENDPATH**/ ?>