<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="row">
            <?php if(Auth::user()->role_id == "1"): ?>
            <div class="col-lg-12 ">
            <?php else: ?>
            <div class="col-lg-8 ">
            <?php endif; ?>
                <div class="card card-default">
                    <div class="card-header card-header-border-bottom">
                        <h2>Bank Toko</h2>
                    </div>

                    
                    <?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <div class="card-body">

                            <table id="basic-data-table" class="table nowrap" style="width:100%">
                                <thead>
                                  <tr>
                                  <th>#</th>
                                  <?php if(Auth::user()->role_id == "1"): ?>
                                    <th>Toko</th>
                                  <?php endif; ?>
                                  <th>Nama Bank</th>
                                  <th>Nomor Rekening</th>
                                  <th>Atas Nama</th>
                                  <th>Action</th>
                                 </tr>
                                </thead>

                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $store_banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store_bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($store_bank->id); ?></td>
                                            <?php if(Auth::user()->role_id == "1"): ?>
                                                <td><?php echo e($store_bank->store->name); ?></td>
                                            <?php endif; ?>
                                            <td><?php echo e($store_bank->bank_name); ?></td>
                                            <td><?php echo e($store_bank->nomor_rekening); ?></td>
                                            <td><?php echo e($store_bank->atas_nama); ?></td>
                                            <td>
                                                <a  href="<?php echo e(route('store_banks.edit', $store_bank->id)); ?>" class="btn btn-sm btn-success"><span class="mdi mdi-pencil"></span></a>
                                                <form action="<?php echo e(route('store_banks.destroy', $store_bank->id)); ?>" method="post" class="d-inline">
                                                    <?php echo method_field('delete'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <button class="btn btn-sm btn-danger"
                                                            onclick="return confirm('Yakin ingin menghapus Bank?');"
                                                    >
                                                        <span class="mdi mdi-delete"></span>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <td class="text-center" colspan="5"> Anda Belum memasukkan Bank </td>
                                    <?php endif; ?>
                                </tbody>
                               </table>

                    </div>
                </div>
            </div>
            <?php if(Auth::user()->role_id == "2"): ?>
            <div class="col-lg-4">
                <div class="card card-default">
                    <div class="card-header card-header-border-bottom">
                        Tambah Bank
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('store_banks.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="bank_name">Nama Bank</label>
                                <input type="text" class="form-control" id="bank_name" name="bank_name" placeholder="Masukkan nama Bank">
                                <span class="mt-2 d-block">* Wajib diisi.</span>
                            </div>
                            <div class="form-group">
                                <label for="nomor_rekening">Nomor Rekening</label>
                                <input type="text" class="form-control" id="nomor_rekening" name="nomor_rekening" placeholder="Masukkan Nomor Rekening">
                                <span class="mt-2 d-block">* Harus unik.</span>
                            </div>
                            <div class="form-group">
                                <label for="atas_nama">Atas Nama</label>
                                <input type="text" class="form-control" id="atas_nama" name="atas_nama" placeholder="Masukkan Atas Nama">
                                <span class="mt-2 d-block">* Wajib diisi.</span>
                            </div>
                            <div class="form-footer pt-2 border-top">
                                <button type="submit" class="btn btn-primary btn-default">Tambah</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php else: ?>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wiku\PROJEK\2 anggara\new klontong\klontong\resources\views/admin/store_banks/index.blade.php ENDPATH**/ ?>