<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12 ftco-animate">
            <div class="cart-list">
                <table class="table">
                    <thead class="thead-primary">
                        <tr class="text-center">
                            <th>&nbsp;</th>
                            <th>Product</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="text-center">

                            <td class="image-prod">
                                <img class="img-fluid" src="<?php echo e(route('gambar', ['path' => $cart_detail->product->image])); ?>"
                                    alt="Colorlib Template" style=" object-fit: contain" width="100px">
                            </td>

                            <td class="product-name">
                                <h3><?php echo e($cart_detail->product->name); ?></h3>
                            </td>

                            <td class="price">Rp. <?php echo e($cart_detail->product->price); ?> </td>

                            <td class="quantity">
                                <div class="input-group mb-3">
                                    <input type="text" name="quantity" class="quantity form-control input-number"
                                        readonly value=<?php echo e($cart_detail->quantity); ?> min="1" max="100">
                                </div>
                            </td>

                            <td class="total">Rp. <?php echo e($cart_detail->total_price()); ?></td>
                        </tr>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <form action="<?php echo e(route('carts.checkout', $cart_detail->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row justify-content-center mt-5 pt-5">
            <?php echo $__env->make('admin.partials.flash', ['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="col-xl-8 ftco-animate fadeInUp ftco-animated">
                <form action="#" class="billing-form">
                    <h3 class="mb-4 billing-heading">Masukkan Alamat pengiriman</h3>
                    <div class="row align-items-end">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="adrress">Alamat</label>
                                <input name="adrress" type="text" class="form-control" placeholder="Alamat">
                            </div>
                        </div>
                        <div class="w-100"></div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="province_id">Provinsi</label>
                                <div class="select-wrap">
                                    <select name="province_id" id="" class="form-control">
                                        <option value="" holder>Pilih provinsi</option>
                                        <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($province->id); ?>"><?php echo e($province->province); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="city_id">Kota</label>
                                <div class="select-wrap">
                                    <select name="city_id" id="" class="form-control">
                                        <option value="" holder>Pilih kota</option>
                                        <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($city->id); ?>"><?php echo e($city->city_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="w-100"></div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="phone">No. HP</label>
                                <input type="number" name="phone" class="form-control" placeholder="">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="phone">Kode Pos</label>
                                <input type="number" name="postal_code" class="form-control" placeholder="">
                            </div>
                        </div>
                        <div class="w-100"></div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="country">Kurir</label>
                                <div class="select-wrap">
                                    <select name="courier" id="" class="form-control">
                                        <option value="" holder>Pilih Kurir</option>
                                        <option value="jne">JNE</option>
                                        <option value="tiki">TIKI</option>
                                        <option value="pos">POS</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6" align="center">
                            <p><button type="submit" class="btn btn-primary py-3 px-4">Cek Pembayaran</button></p>
                        </div>
                    </div>
                </form><!-- END -->
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wiku\PROJEK\2 anggara\new klontong\klontong\resources\views/user/checkout.blade.php ENDPATH**/ ?>