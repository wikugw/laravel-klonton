<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="row">
            <div class="col-lg-12">
                <div class="card card-default">
                    <div class="card-header card-header-border-bottom">
                        <h2>Produk</h2>
                    </div>

                    
                    <?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <div class="card-body">
                        <table id="basic-data-table" class="table nowrap" style="width:100%">
                            <thead>
                              <tr>
                              <th>#</th>
                              <th>Nama Produk</th>
                              <th>Kategori</th>
                              <th>Berat</th>
                              <th>Harga</th>
                              <th>Tersedia</th>
                              <th>Toko</th>
                              <th>Action</th>
                             </tr>
                            </thead>

                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($product->id); ?></td>
                                        <td><?php echo e($product->name); ?></td>
                                        <td><?php echo e($product->category->name); ?></td>
                                        <td><?php echo e($product->weight); ?></td>
                                        <td><?php echo e($product->price); ?></td>
                                        <td>
                                            <?php if($product->is_available == '0'): ?>
                                                <span class="badge badge-danger">Habis</span>
                                            <?php else: ?>
                                                <span class="badge badge-success">Tersedia</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($product->store->name); ?></td>
                                        <td>
                                            <?php if($product->is_active == '0'): ?>
                                            <a  href="<?php echo e(route('products.activate', $store->id)); ?>"
                                                class="btn btn-sm btn-primary"
                                                onclick="return confirm('Yakin ingin mengaktifkan toko?');"
                                            >
                                                <span class="mdi mdi-check"></span>
                                            </a>
                                            <?php endif; ?>
                                            <a  href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-sm btn-success"><span class="mdi mdi-pencil"></span></a>
                                            <a  href="<?php echo e(route('products.show', $product->id)); ?>" class="btn btn-sm btn-info"><span class="mdi mdi-eye"></span></a>
                                            <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="post" class="d-inline">
                                                <?php echo method_field('delete'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button class="btn btn-sm btn-danger"
                                                        onclick="return confirm('Yakin ingin menghapus produk?');"
                                                >
                                                    <span class="mdi mdi-delete"></span>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <td class="text-center" colspan="8"> Produk tidak ditemukan </td>
                                <?php endif; ?>
                            </tbody>
                           </table>
                           <div class="form-footer pt-4 text-right">
                            <?php if(Auth::user()->role_id == '2' && Auth::user()->store->is_active == '1'): ?>
                            <a href="<?php echo e(route('products.create')); ?>"
                                class="btn btn-primary btn-sm btn-default">Tambah Produk</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wiku\PROJEK\2 anggara\new klontong\klontong\resources\views/admin/products/index.blade.php ENDPATH**/ ?>