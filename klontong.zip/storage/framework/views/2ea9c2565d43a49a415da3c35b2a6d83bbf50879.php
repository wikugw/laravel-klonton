<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        
        <div class="col-md-4 cart-wrap ftco-animate fadeInUp ftco-animated">
            <div class="cart-total mb-3">
                <h3>Informasi Toko</h3>
                <p class="d-flex">
                    <span>Nama Toko</span>
                    <span><?php echo e($cart->store['name']); ?></span>
                </p>
                <hr>
                <p class="d-flex">
                    <span>Alamat</span>
                    <span><?php echo e($origin_address->adrress); ?></span>
                </p>
                <p class="d-flex">
                    <span>Kota</span>
                    <span><?php echo e($origin_address->city->city_name); ?></span>
                </p>
                <p class="d-flex">
                    <span>Provinsi</span>
                    <span><?php echo e($origin_address->province->province); ?></span>
                </p>
                <p class="d-flex">
                    <span>Kode Pos</span>
                    <span><?php echo e($origin_address->postal_code); ?></span>
                </p>
                <hr>
                <p class="d-flex">
                    <span>No. HP</span>
                    <span><?php echo e($origin_address->phone); ?></span>
                </p>
            </div>
        </div>
        
        <div class="col-md-4 cart-wrap ftco-animate fadeInUp ftco-animated">
            <div class="cart-total mb-3">
                <h3>Informasi Pembeli</h3>
                <p class="d-flex">
                    <span>Nama Pembeli</span>
                    <span><?php echo e(Auth::user()->name); ?></span>
                </p>
                <hr>
                <p class="d-flex">
                    <span>Alamat</span>
                    <span><?php echo e($destination_address->adrress); ?></span>
                </p>
                <p class="d-flex">
                    <span>Kota</span>
                    <span><?php echo e($destination_address->city->city_name); ?></span>
                </p>
                <p class="d-flex">
                    <span>Provinsi</span>
                    <span><?php echo e($destination_address->province->province); ?></span>
                </p>
                <p class="d-flex">
                    <span>Kode Pos</span>
                    <span><?php echo e($destination_address->postal_code); ?></span>
                </p>
                <hr>
                <p class="d-flex">
                    <span>No. HP</span>
                    <span><?php echo e($destination_address->phone); ?></span>
                </p>
                <p class="d-flex">
                    <span>Kurir</span>
                    <span style="text-transform:uppercase;"><?php echo e($picked_service); ?></span>
                </p>
            </div>
        </div>
        
        <div class="col-md-4 cart-wrap ftco-animate fadeInUp ftco-animated">
            <div class="cart-total mb-3">
                <h3>Detail Produk</h3>
                <p class="d-flex">
                    <span>Nama</span>
                    <span><?php echo e($product->name); ?></span>
                </p>
                <p class="d-flex">
                    <span>Jumlah</span>
                    <span><?php echo e($cart_detail->quantity); ?></span>
                </p>
                <hr>
                <p class="d-flex">
                    <span>Berat</span>
                    <span><?php echo e($product->weight); ?></span>
                </p>
                <p class="d-flex total-price">
                    <span>Berat Total</span>
                    <span style="text-transform:capitalize;"><?php echo e($weight_total); ?> gram</span>
                </p>
                <hr>
                <p class="d-flex">
                    <span>Harga</span>
                    <span>Rp. <?php echo e($product->price); ?></span>
                </p>
                <p class="d-flex total-price">
                    <span>Harga Total</span>
                    <span style="text-transform:capitalize;">Rp. <?php echo e($price_total); ?></span>
                </p>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12 ftco-animate">
            <div class="cart-list">
                <table class="table">
                    <thead class="thead-primary">
                        <tr class="text-center">
                            <th>Nama Service</th>
                            <th>Harga Ongkir</th>
                            <th>Total Harga</th>
                            <th>Estimasi Pengiriman</th>
                            <th>Note</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <form enctype="multipart/form-data"
                            action="<?php echo e(route('carts.checkout.pay', ['id' => $cart_detail->id, 'address_id' => $destination_address->id, 'courier' => $picked_service])); ?>"
                            method="POST">
                            <?php echo csrf_field(); ?>
                            <tr class="text-center">

                                <td class="product-name">
                                    <h3><?php echo e($service['description']); ?> (<?php echo e($service['service']); ?>)</h3>
                                </td>

                                <td class="price">
                                    Rp. <?php echo e($service['cost'][0]['value']); ?>

                                    <input type="hidden" name="subtotal" value="<?php echo e($price_total); ?>">
                                </td>

                                <td class="price">
                                    Rp. <?php echo e(( $price_total + $service['cost'][0]['value'])); ?>

                                </td>

                                <td class="price">
                                    <?php echo e($service['cost'][0]['etd']); ?>

                                </td>

                                <?php if($service['cost'][0]['note'] == ""): ?>
                                <td class="price">
                                    -
                                </td>
                                <?php else: ?>
                                <td class="price">
                                    <?php echo e($service['cost'][0]['note']); ?>

                                </td>
                                <?php endif; ?>

                                <td>
                                    
                                    <button type="button" class="btn btn-primary" data-toggle="modal"
                                        data-target="#exampleModal"
                                        data-ongkir="<?php echo e($service['cost'][0]['value']); ?>"
                                        data-service="<?php echo e(strtoupper($picked_service)); ?> - <?php echo e($service['description']); ?> (<?php echo e($service['service']); ?>)"
                                        data-whatever="<?php echo e(( $price_total + $service['cost'][0]['value'])); ?>">
                                        Pilih
                                    </button>
                                </td>

                            </tr>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <td class="text-center" colspan="8">Jasa pengiriman tidak dapat ditemukan, coba jassa lain
                                :(
                            </td>
                            <?php endif; ?>
                            <!-- END TR-->

                    </tbody>
                </table>
            </div>
        </div>
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Ikuti Instruksi untuk menyelesaikan transaksi
                            </h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                    </div>
                    <div class="modal-body">
                            <div class="col-md-12 cart-wrap ftco-animate fadeInUp ftco-animated">
                                <div class="cart-total mb-3">
                                    <input type="hidden" name="service" id="service"
                                        value="<?php echo e($service['description']); ?> (<?php echo e($service['service']); ?>)">
                                    <input type="hidden" name="ongkir" id="ongkir" value="<?php echo e($service['cost'][0]['value']); ?>">
                                    <h3 id="bayar">1. Lakukan Transfer Pada salah 1 Bank dibawah ini</h3>
                                    <p class="d-flex px-5">
                                        <span style="color: black;">Nama Bank</span>
                                        <span style="color: black;">Nomor Rekening</span>
                                        <span style="color: black;">Atas Nama</span>
                                    </p>
                                    <?php $__empty_1 = true; $__currentLoopData = $store_banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store_bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <p class="d-flex px-5">
                                        <span><?php echo e($store_bank->bank_name); ?></span>
                                        <span><?php echo e($store_bank->nomor_rekening); ?></span>
                                        <span><?php echo e($store_bank->atas_nama); ?></span>
                                    </p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <span>Sayang sekali tidak dapat menemukan Bank :(</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-12 cart-wrap ftco-animate fadeInUp ftco-animated">
                                <div class="cart-total mb-3">
                                    <h3>2. Upload bukti Transfer dan Tekan Tombol "Saya Telah Bayar"</h3>
                                    <p class="d-flex px-5">
                                        <div class="form-control">
                                            <input type="file" name="image" required>
                                        </div>
                                    </p>
                                </div>
                            </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Saya Telah Bayar</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

        <div class="col-12" align="center">
            <form action="<?php echo e(route('carts.delete_address', ['id' => $cart_detail->id, 'address_id' => $destination_address->id])); ?>" method="post"
                class="d-inline">
                <?php echo method_field('delete'); ?>
                <?php echo csrf_field(); ?>
                <button class="mt-5 btn btn-secondary" onclick="return confirm('Dengan menekan tombol ini anda harus memasukkan alamat ulang');">
                    Kembali
                </button>
            </form>
        </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wiku\PROJEK\2 anggara\new klontong\klontong\resources\views/user/transfer.blade.php ENDPATH**/ ?>