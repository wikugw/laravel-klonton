<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="card card-default">
                    <div class="card-header card-header-border-bottom">
                        Tambah Resi Transaksi dengan kode <br> <?php echo e($transaction->code); ?>

                    </div>
                    <div class="card-body">
                        <?php echo $__env->make('admin.partials.flash', ['$errors' => $errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <form action="<?php echo e(route('transactions.add_resi', $transaction->id)); ?>" method="POST">
                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="resi">Nomor Resi</label>
                                <input type="text" class="form-control" id="resi"
                                        value="<?php echo e(old('resi') ? old('resi') : $transaction->resi); ?>"
                                        name="resi" placeholder="Masukkan kategori">
                                <span class="mt-2 d-block">* Harus Unik.</span>
                            </div>
                            <div class="form-footer pt-2 border-top">
                                <button type="submit" class="btn btn-primary btn-default">Tambahkan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wiku\PROJEK\2 anggara\new klontong\klontong\resources\views/admin/transactions/add_resi.blade.php ENDPATH**/ ?>