 <!-- Header -->
 <header class="main-header " id="header">
    <nav class="navbar navbar-static-top navbar-expand-lg">
      <!-- Sidebar toggle button -->
      <button id="sidebar-toggler" class="sidebar-toggle">
        <span class="sr-only">Toggle navigation</span>
      </button>
      <!-- search form -->
      <div class="search-form d-none d-lg-inline-block">
      </div>

      <div class="navbar-right ">
        <ul class="nav navbar-nav">
            
            <li class="dropdown user-menu">
                <button class="dropdown-toggle" data-toggle="dropdown">
                    <span class="d-none d-lg-inline-block">Notifikasi </span>
                    <span class="badge badge-sm badge-light"><?php echo e(auth()->user()->unreadNotifications->where('data.for', '!=' , 'user')->count()); ?></span>
                </button>
                <ul class="dropdown-menu dropdown-menu-right">
                  <?php $__empty_1 = true; $__currentLoopData = auth()->user()->unreadNotifications->where('data.for', '!=' , 'user'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <li>
                      <?php if($notification->data['for'] == 'admin'): ?>
                      <a href="<?php echo e(route('stores.index')); ?>" style="color: black">
                        <?php echo e($notification->data['message']); ?>

                        <?php else: ?>
                        <a href="<?php echo e(route('stores.transactions', auth()->user()->store_id)); ?>" style="color: black">
                            <?php echo e($notification->data['message']); ?>

                      <?php endif; ?>

                    </a>
                  </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <li>
                    <a class="text-center" href="#"> Tidak ada notifikasi </a>
                  </li>
                  <?php endif; ?>
                  <?php if(!auth()->user()->unreadNotifications->where('data.for', '!=' , 'user')->isEmpty()): ?>
                  <li class="dropdown-footer">
                    <a class="text-center" href="<?php echo e(route('markAsRead', 'store')); ?>"> Tandai semua telah terbaca </a>
                  </li>
                  <?php endif; ?>
                </ul>
              </li>
          <!-- User Account -->
          <li class="dropdown user-menu">
            <button href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
                <?php if(Auth::user()->profile_photo == ''): ?>
                <img src="<?php echo e(url('storage/foto_user/kosong.png')); ?>" class="user-image"/>
                <?php else: ?>
                <img src="<?php echo e(route('gambar', ['path' => Auth::user()->profile_photo])); ?>" alt="profile toko" class="user-image">
                <?php endif; ?>
              <span class="d-none d-lg-inline-block"><?php echo e(Auth::user()->name); ?></span>
            </button>
            <ul class="dropdown-menu dropdown-menu-right">
              <!-- User image -->
              <li class="dropdown-header">
                <?php if(Auth::user()->profile_photo == ''): ?>
                <img src="<?php echo e(url('storage/foto_user/kosong.png')); ?>" class="img-circle"/>
                <?php else: ?>
                <img src="<?php echo e(route('gambar', ['path' => Auth::user()->profile_photo])); ?>" alt="profile toko" class="img-circle">
                <?php endif; ?>
                <div class="d-inline-block">
                    <?php echo e(Auth::user()->name); ?> <small class="pt-1"><?php echo e(Auth::user()->email); ?></small>
                </div>
              </li>
              <?php if(Auth::user()->role_id == '1'): ?>
              <?php elseif(Auth::user()->store_id == ''): ?>
              <li>
                <a href="<?php echo e(route('stores.create')); ?>">
                  <i class="mdi mdi-store"></i> Buat Toko
                </a>
              </li>
              <?php else: ?>
              <li>
                <a href="<?php echo e(route('stores.show', Auth::user()->store_id)); ?>">
                  <i class="mdi mdi-store"></i> Lihat Toko
                </a>
              </li>
              <li>
                <a href="<?php echo e(route('products.create')); ?>">
                  <i class="mdi mdi-clipboard"></i> Tambah Produk
                </a>
              </li>
              <?php endif; ?>
              <li>
                <a href="<?php echo e(route('users.show', Auth::user()->id)); ?>"> <i class="mdi mdi-account"></i> Profile </a>
              </li>
              <li class="right-sidebar-in">
                <a href="<?php echo e(route('home')); ?>"> <i class="mdi mdi-shopping"></i> Ke halaman belanja </a>
              </li>

              <li class="dropdown-footer">
                    <a  href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();"
                    >
                        <i class="mdi mdi-logout"></i> Log Out
                    </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
              </li>
            </ul>
          </li>
        </ul>
      </div>
    </nav>


  </header>
<?php /**PATH D:\wiku\PROJEK\2 anggara\new klontong\klontong\resources\views/admin/partials/header.blade.php ENDPATH**/ ?>