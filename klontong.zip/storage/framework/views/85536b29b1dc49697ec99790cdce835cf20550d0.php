<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12 ftco-animate">
            <div class="cart-list">
                <table class="table">
                    <thead class="thead-primary">
                        <tr class="text-center">
                            <th>&nbsp;</th>
                            <th>Product</th>
                            <th>Quantity</th>
                            <th>Status</th>
                            <th>Resi</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $transaction_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="text-center">

                            <td class="image-prod">
                                <img class="img-fluid" src="<?php echo e(route('gambar', ['path' => $transaction_detail->product->image])); ?>"
                                    alt="Colorlib Template" style=" object-fit: contain" width="100px">
                            </td>

                            <td class="product-name">
                                <h3><?php echo e($transaction_detail->product->name); ?></h3>
                            </td>

                            <td class="price"><?php echo e($transaction_detail->quantity); ?> </td>

                            <td class="price"
                                <?php if($transaction_detail->transaction->status == '1'): ?>
                                style="color: red;"> Menunggu Konfirmasi
                                <?php elseif($transaction_detail->transaction->status == '2'): ?>
                                style="color: orange;"> Menunggu Resi
                                <?php elseif($transaction_detail->transaction->status == '3'): ?>
                                style="color: green;"> Barang Telah dikirim
                                <?php elseif($transaction_detail->transaction->status == '4'): ?>
                                style="color: green;"> Transaksi Selesai
                                <?php endif; ?>
                            </td>

                            <td class="price">
                                <?php if($transaction_detail->transaction->resi == null): ?>
                                Menunggu Resi ditambahkan
                                <?php else: ?>
                                    <?php echo e($transaction_detail->transaction->resi); ?>

                                <?php endif; ?>
                            </td>

                            <td class="price">
                                <?php if($transaction_detail->transaction->status == '3'): ?>
                                <a
                                    href="<?php echo e(route('home.receive', $transaction_detail->transaction->id)); ?>"
                                    class="btn btn-sm btn-primary"
                                    onclick="return confirm('Dengan menekan tombol ini anda akan menyelesaikan transaksi');">
                                    Barang telah saya terima
                                </a>
                                <?php else: ?>
                                -
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <td class="text-center" colspan="8">Anda belum melakukan transaksi :(</td>
                        <?php endif; ?>
                        <!-- END TR-->

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wiku\PROJEK\2 anggara\new klontong\klontong\resources\views/user/transactions.blade.php ENDPATH**/ ?>