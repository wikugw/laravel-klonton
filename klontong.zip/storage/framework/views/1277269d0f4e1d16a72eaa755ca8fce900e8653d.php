<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12 col-lg-12 order-md-last">
            <div class="row">
                
                <?php $__empty_1 = true; $__currentLoopData = $store_addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store_address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-sm-6 col-md-6 col-lg-3 ftco-animate">
                    <div class="product">
                        <a href="#" class="img-prod"><img class="img-fluid"
                            src="<?php echo e(route('gambar', ['path' => $store_address->store->profile])); ?>"
                            alt="Colorlib Template" style="height: 300px; object-fit: contain" width="100%">
                            <div class="overlay"></div>
                        </a>
                        <div class="text py-3 px-3">
                            <h3 style="font-weight: bold"><a href="#"><?php echo e($store_address->store->name); ?></a></h3>
                            <div class="d-flex">
                                <div class="pricing">
                                    <p class="price"><span>Kota <?php echo e($store_address->city->city_name); ?></span></p>
                                </div>
                                <div class="rating">
                                    <p class="text-right">
                                        <a href="<?php echo e(route('home.store', $store_address->store_id)); ?>" class="btn btn-sm btn-primary">Detail</a>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="container">
                    <div class="row justify-content-center mt-5 mb-3 pb-3">
              <div class="col-md-12 heading-section text-center ftco-animate fadeInUp ftco-animated">
                <h4 class="mb-4">Toko tidak ditemukan :(</h4>
              </div>
            </div>
            </div>
                <?php endif; ?>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wiku\PROJEK\2 anggara\new klontong\klontong\resources\views/user/stores.blade.php ENDPATH**/ ?>