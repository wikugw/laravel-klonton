<head>
<style>
    table, td, th {
  border: 1px solid black;
}

table {
  border-collapse: collapse;
  width: 100%;
}

th {
  height: 50px;
}
td {
    padding-left: 10px;
}

.kosong {
    margin-top: 5px !important;
    border: 1px solid black !important;
}
</style>
</head>

<body>
    <div align="center">
        <h2>Data Transaksi Aplikasi Klontong</h2>
        <?php if(Auth::user()->role_id == '2'): ?>
            <h3>Toko <?php echo e(Auth::user()->store->name); ?></h3>
        <?php else: ?>
            <h3>Admin</h3>
        <?php endif; ?>
    </div>
    <table class="table">
        <thead>
            <tr>
                <th>Kode Transaksi</th>
                <?php if(Auth::user()->role_id == '1'): ?>
                <th>Nama Toko</th>
                <?php endif; ?>
                <th>Nama Produk</th>
                <th>Nama Pembeli</th>
                <th>Alamat</th>
                <th>Kurir</th>
                <th>Subtotal</th>
                <th>Ongkir</th>
                <th>Resi</th>
                <th>Status</th>
                <th>Tanggal Transfer</th>
            </tr>

            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $transaction_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($transaction_detail->transaction->code); ?></td>
                    <?php if(Auth::user()->role_id == '1'): ?>
                    <td><?php echo e($transaction_detail->transaction->store->name); ?></td>
                    <?php endif; ?>
                    <td><?php echo e($transaction_detail->product->name); ?></td>
                    <td><?php echo e($transaction_detail->transaction->user->name); ?></td>
                    <td><?php echo e($transaction_detail->transaction->address->adrress); ?>,
                        <?php echo e($transaction_detail->transaction->address->city->city_name); ?>,
                        <?php echo e($transaction_detail->transaction->address->province->province); ?>,
                        <?php echo e($transaction_detail->transaction->address->postal_code); ?>

                    </td>
                    <td><?php echo e($transaction_detail->transaction->service); ?></td>
                    <td>Rp. <?php echo e($transaction_detail->transaction->subtotal); ?></td>
                    <td>Rp. <?php echo e($transaction_detail->transaction->ongkir); ?></td>
                    <td>
                        <?php if($transaction_detail->transaction->resi): ?>
                        <?php echo e($transaction_detail->transaction->resi); ?>

                        <?php else: ?>
                        -
                        <?php endif; ?>
                    </td>
                    <td <?php if($transaction_detail->transaction->status == '1'): ?>
                        style="color: red;"> Menunggu Konfirmasi
                        <?php elseif($transaction_detail->transaction->status == '2'): ?>
                        style="color: orange;"> Menunggu Resi
                        <?php elseif($transaction_detail->transaction->status == '3'): ?>
                        style="color: green;"> Barang Telah dikirim
                        <?php elseif($transaction_detail->transaction->status == '4'): ?>
                        style="color: green;"> Barang Telah diterima
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($transaction_detail->transaction->created_at); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <td class="kosong" align="center" colspan="10"> Belum ada transaksi </td>
                <?php endif; ?>
            </tbody>
        </thead>
    </table>
</body>
<?php /**PATH D:\wiku\PROJEK\2 anggara\new klontong\klontong\resources\views/admin/transactions/pdf.blade.php ENDPATH**/ ?>