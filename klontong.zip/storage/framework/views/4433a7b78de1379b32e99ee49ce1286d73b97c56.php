<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="row">
            <div class="col-lg-12">
                <div class="card card-default">
                    <div class="card-header card-header-border-bottom">
                        <h2>Toko</h2>
                    </div>

                    
                    <?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <div class="card-body">
                        <table id="basic-data-table" class="table nowrap" style="width:100%">
                            <thead>
                              <tr>
                              <th>#</th>
                              <th>Nama Toko</th>
                              <th>User</th>
                              <th>Status</th>
                              <th>Action</th>
                             </tr>
                            </thead>

                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($store->id); ?></td>
                                        <td><?php echo e($store->name); ?></td>
                                        <td><?php echo e($store->user->name); ?></td>
                                        <td>
                                            <?php if($store->is_active == '0'): ?>
                                                <span class="badge badge-warning">Pending</span>
                                            <?php else: ?>
                                                <span class="badge badge-success">Active</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($store->is_active == '0'): ?>
                                            <a  href="<?php echo e(route('stores.activate', $store->id)); ?>"
                                                class="btn btn-sm btn-primary"
                                                onclick="return confirm('Yakin ingin mengaktifkan toko?');"
                                            >
                                                <span class="mdi mdi-check"></span>
                                            </a>
                                            <?php endif; ?>
                                            <a  href="<?php echo e(route('stores.edit', $store->id)); ?>" class="btn btn-sm btn-success"><span class="mdi mdi-pencil"></span></a>
                                            <a  href="<?php echo e(route('stores.show', $store->id)); ?>" class="btn btn-sm btn-info"><span class="mdi mdi-eye"></span></a>
                                            <form action="<?php echo e(route('stores.destroy', $store->id)); ?>" method="post" class="d-inline">
                                                <?php echo method_field('delete'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button class="btn btn-sm btn-danger"
                                                        onclick="return confirm('Yakin ingin menghapus toko?');"
                                                >
                                                    <span class="mdi mdi-delete"></span>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <td class="text-center" colspan="5"> Toko tidak ditemukan </td>
                                <?php endif; ?>
                            </tbody>
                           </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wiku\PROJEK\2 anggara\new klontong\klontong\resources\views/admin/stores/index.blade.php ENDPATH**/ ?>