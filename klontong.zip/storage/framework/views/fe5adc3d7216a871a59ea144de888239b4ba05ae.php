<?php $__env->startSection('content'); ?>
<div class="content">
    
    <?php echo $__env->make('admin.partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="bg-white border rounded">
        <div class="row no-gutters">
            <div class="col-lg-4 col-xl-3">
                <div class="profile-content-left pt-5 pb-3 px-3 px-xl-5">
                    <div class="card text-center widget-profile px-0 border-0">
                        <div class="card-img mx-auto rounded-circle">
                            <?php if($store->profile == ""): ?>
                            <img src="<?php echo e(url('storage/profile_toko/kosong.png')); ?>" />
                            <?php else: ?>
                            <img src="<?php echo e(route('gambar', ['path' => $store->profile])); ?>" alt="profile toko" width="100%" height="100%">
                            <?php endif; ?>
                        </div>
                        <div class="card-body">
                            <p class="text-dark font-weight-medium pt-4 mb-2">Nama Toko</p>
                            <h4 class="py-2 text-dark mb-2"><?php echo e($store->name); ?></h4>
                            <p class="text-dark font-weight-medium pt-4 mb-2">Nama Pemilik Toko</p>
                            <h5 class="py-2 text-dark mb-2"><?php echo e($store->user->name); ?></h5>
                        </div>
                    </div>
                    <div class="contact-info text-center">
                        <p class="text-dark font-weight-medium pt-4 mb-2">Status Toko</p>
                        <?php if($store->is_active == '0'): ?>
                        <span class="badge badge-warning py-2 ">Pending</span>
                        <?php else: ?>
                        <span class="badge badge-success py-2 ">Active</span>
                        <?php endif; ?>
                        <a href="<?php echo e(route('stores.edit', $store->id)); ?>" class="py-2 mt-3 btn btn-sm btn-secondary btn-block">Edit
                            Toko</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-8 col-xl-9">
                <div class="profile-content-right py-5">
                    <ul class="nav nav-tabs px-3 px-xl-5 nav-style-border" id="myTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="timeline-tab" data-toggle="tab" href="#info" role="tab"
                                aria-controls="info" aria-selected="false">Info</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="address-tab" data-toggle="tab" href="#address" role="tab"
                                aria-controls="address" aria-selected="false">Alamat</a>
                        </li>
                    </ul>
                    <div class="tab-content px-3 px-xl-5" id="myTabContent">
                        <div class="tab-pane fade active show" id="info" role="tabpanel" aria-labelledby="info-tab">
                            <h4 class="pt-4 text-dark mb-2">Deskripsi</h4>
                            <p class="py-2 text-dark mb-2"><?php echo e($store->description); ?></p>
                            <h4 class="pt-4 text-dark mb-3">Foto KTP</h4>
                            <img src="<?php echo e(route('gambar', ['path' => $store->foto_ktp])); ?>" class="img-thumbnail" alt="profile toko">
                        </div>
                        <div class="tab-pane fade" id="product" role="tabpanel" aria-labelledby="product-tab">
                            <div class="py-4">
                                <table id="basic-data-table" class="table nowrap pt-3" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Nama Produk</th>
                                            <th>Kategori</th>
                                            <th>Berat</th>
                                            <th>Harga</th>
                                            <th>Tersedia</th>
                                            <th>Toko</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($product->id); ?></td>
                                            <td><?php echo e($product->name); ?></td>
                                            <td><?php echo e($product->category->name); ?></td>
                                            <td><?php echo e($product->weight); ?></td>
                                            <td><?php echo e($product->price); ?></td>
                                            <td>
                                                <?php if($product->is_available == '0'): ?>
                                                <span class="badge badge-danger">Habis</span>
                                                <?php else: ?>
                                                <span class="badge badge-success">Tersedia</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($product->store->name); ?></td>
                                            <td>
                                                <?php if($product->is_active == '0'): ?>
                                                <a href="<?php echo e(route('products.activate', $store->id)); ?>"
                                                    class="btn btn-sm btn-primary"
                                                    onclick="return confirm('Yakin ingin mengaktifkan produk?');">
                                                    <span class="mdi mdi-check"></span>
                                                </a>
                                                <?php endif; ?>
                                                <a href="<?php echo e(route('products.edit', $product->id)); ?>"
                                                    class="btn btn-sm btn-success"><span
                                                        class="mdi mdi-pencil"></span></a>
                                                <a href="<?php echo e(route('products.show', $product->id)); ?>"
                                                    class="btn btn-sm btn-info"><span class="mdi mdi-eye"></span></a>
                                                <form action="<?php echo e(route('products.destroy', $product->id)); ?>"
                                                    method="post" class="d-inline">
                                                    <?php echo method_field('delete'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <button class="btn btn-sm btn-danger"
                                                        onclick="return confirm('Yakin ingin menghapus produk?');">
                                                        <span class="mdi mdi-delete"></span>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <td class="text-center" colspan="8"> Produk tidak ditemukan </td>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                                <div class="form-footer pt-4 text-right">
                                    <?php if($store->is_active == '1'): ?>
                                    <a href="<?php echo e(route('products.create')); ?>"
                                        class="btn btn-primary btn-sm btn-default">Tambah Produk</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="address" role="tabpanel" aria-labelledby="address-tab">
                           <?php if($address): ?>
                            <h4 class="pt-4 text-dark mb-2">Alamat</h4>
                            <h5 class="my-3 font-weight-medium"><?php echo e($address->adrress); ?></h5>

                            <div class="row">
                                <div class="col-3 py-3">
                                    <h5 class="text-dark font-weight-medium">Kota:</h5>
                                </div>
                                <div class="col-3 py-3">
                                    <h5 class="font-weight-medium"><?php echo e($address->city->city_name); ?></h5>
                                </div>
                                <div class="col-3 py-3">
                                    <h5 class="text-dark font-weight-medium">Provinsi:</h5>
                                </div>
                                <div class="col-3 py-3">
                                    <h5 class="font-weight-medium"><?php echo e($address->province->province); ?></h5>
                                </div>
                                <div class="col-3 py-3">
                                    <h5 class="text-dark font-weight-medium">No HP:</h5>
                                </div>
                                <div class="col-3 py-3">
                                    <h5 class="font-weight-medium"><?php echo e($address->phone); ?></h5>
                                </div>
                                <div class="col-3 py-3">
                                    <h5 class="text-dark font-weight-medium">Kode Pos</h5>
                                </div>
                                <div class="col-3 py-3">
                                    <h5 class="font-weight-medium"><?php echo e($address->postal_code); ?></h5>
                                </div>
                            </div>
                           <?php else: ?>
                           <a href="<?php echo e(route('addresses.create')); ?>" class="btn btn-primary btn-block mt-5">Tambahkan
                            alamat</a>
                           <?php endif; ?>
                        </div>

                        <div class="tab-pane fade" id="store_bank" role="tabpanel" aria-labelledby="store_bank-tab">
                            <a  href="<?php echo e(route('store_banks.create')); ?>"
                                class="btn btn-primary btn-sm btn-default">Tambah Bank</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wiku\PROJEK\2 anggara\new klontong\klontong\resources\views/admin/stores/show.blade.php ENDPATH**/ ?>