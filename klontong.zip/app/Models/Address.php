<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Address extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'user_id',
        'store_id',
        'phone',
        'adrress',
        'city_id',
        'province_id',
        'postal_code'
    ];

    public function city()
    {
        return $this->belongsTo('App\Models\City');
    }

    public function province()
    {
        return $this->belongsTo('App\Models\Province');
    }

    public function transaction()
    {
        return $this->hasOne('App\Models\Transaction');
    }

    public function store()
    {
        return $this->belongsTo('App\Models\Store');
    }
}
